from aiogram import Bot
from aiogram.types import BotCommand

from commands.command_name import START_COMMAND


async def set_bot_command(bot: Bot):
    date = [
        (
            [
                BotCommand(command=START_COMMAND)
            ]
        )
    ]
