from aiogram.utils import markdown

MESSAGE_RESET_CONTEXT = r'Чат очищен'
MESSAGE_TO_RESET_CONTEXT = r'Завершить диалог'
MESSAGE_TO_REPLAY = r'Повторить попытку'

ERROR_RESPONSE_MESSAGE = r'Ошибка'
TOO_FAST_RESPONSE_MESSAGE = "Слишком быстро"
AWAIT_RESPONSE_MESSAGE = r'Подождите'
NONE_LAST_MESSAGE = r'Извините, но предидущего сообщения несуществует'

REGISTRATIONS_MESSAGE = "Зарегестрируйтесь"
REGISTRATIONS = r'Регистрация'

NOT_ENOUGH_FUNDS = r'Недостаточно средств'

START_MESSAGE = "Здравструйте"
START_RESPONSE = "Стартуем"

SUBSCRIBER_TO_CHANNEL = " ПОДПИШЬ НА КАНАЛ!!ДУРА"
URL_TO_SUBSCRIBE = "ДУРА ЧТО ЛИ?"

THROTTLED_MESSAGE = "БЕЗ СПАМА"

EMPTY_ARGUMENTS_COMMAND = "ПУСТОЕ СООБЩЕНИЕ"

REFERRAL_OF_YOURSELF = "Применяь реферальную ссылку к самому к себе нельза!читерюга!"
REFERRAL_BAD_CODE = "Неправильный код "
REFERRAL_SUCCESS = "Успешно"
YOUR_REFERRAL_SUCCESS = "Успешно"
REFERRAL_NOT_EXIST = "Такой ссылки не существует"
REFERRAL_EXIST = "Вы уже регистрировались по этой ссылке, никаких бонусов"
REFERRAL_UNAVAILABLE = "Извините, ссылка неоступна"
REFERRAL_GET_CODE = "Ваш код для регистрации рефералов"
REFERRAL_GET_LINK = "Ваша ссылка для регистрации рефералов"
REFERRAL_LINK_TEMPLATE = r'https://t.me/ВАШБОТ?start={}'
REFERRAL_START_ADD_BY_CODE = "Введите реферальную ссылку"

PROMO_CODE_START_MESSAGE = r'Введите промокод'
PROMO_CODE_ACTIVE_STATUS = r'Промокод успешно активирован'
PROMO_CODE_USED_STATUS = r'Промокод уже использован'
PROMO_CODE_DISABLE_STATUS = r'Промокод отключён'
PROMO_CODE_NONE_STATUS = r'Такого промокода несуществует'

CANCEL_MESSAGE = r'Отменено'
TO_CANCEL_MESSAGE = r'Отменить'

CHOSE_ACTIONS = r'Выберите действие'

TOKEN_ABOUT = "Токены нужны для взаимодействия с ChatGPT. Их количество можно посмотреть в профиле"

IMAGE_MESSAGE = r'Генерация картинки... '

PROFILE = "Ваш профиль"

