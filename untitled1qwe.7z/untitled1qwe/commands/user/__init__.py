from aiogram import Router

from Middleware.User import UserMiddleware
from Middleware.data_base_connection import DatabaseMiddleware
from commands.start import user_start_router
from commands.user.gpt_image import user_gpt_image_router

user_router = Router(name="user")

user_router.message.middleware(DatabaseMiddleware)
user_router.message.middleware(UserMiddleware)

user_router.callback_query.middleware(DatabaseMiddleware)
user_router.callback_query.middleware(UserMiddleware)

user_router.include_router(user_start_router, user_gpt_image_router)