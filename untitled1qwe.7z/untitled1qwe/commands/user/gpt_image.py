from aiogram import Router, Bot, F
from aiogram.enums import chat_type, ChatType
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import message

from data_base.models import Users
from filters import ChatTypeFilter
from parameters.bot_parameters import PARSE_MOD
from parameters.responses_template import START_RESPONSE
from structures.enums.image import OrderImageGenerate
from structures.enums.roles import Role

user_gpt_image_router = Router()


user_gpt_image_router.message.middleware(RoleMiddleware())
user_gpt_image_router.message.middleware(BalanceMiddleware())

@user_gpt_image_router(
    ChatTypeFilter(chat_type =[ChatType.PRIVATE]),
    Command(IMAGE_COMMAND),
    filter={"chat_action":"typing"}
)
async def cmd_start_image_generate(message: type.Message, state : FSMContext):
    opening_message = await message.answer(IMAGE_COMMAND,
                                           disable_notification = True,
                                           parse_mode = PARSE_MOD)
    await state.set_state(OrderImageGenerate.image_generate)

@user_gpt_image_router(
    ChatTypeFilter(chat_type =[ChatType.PRIVATE]),
    OrderImageGenerate.image_generate,
    F.text,
    filter={"chat_action":"upload_photo"}
)
async def cmd_image_generate(message: type.Message, state : FSMContext, user: Users, bot: Bot):
    opening_message = await message.answer(START_RESPONSE.format(user.balance),
                                           disable_notification = True,
                                           parse_mode = PARSE_MOD)
    success, response, token = await get_image_response(message.from_user.id)
    if success:
        await bot.send_photo(chat_id=message.from_user.id, photo=response)
        await debitting_tokens(user, token)
        await state.clear()
    if not success:
        await bot.send_message(chat_id=message.from__user.id, text=response)
    await opening_message.delete()
