from os import getenv

from  openai_async import  openai_async

from parameters.gpt_parameters import IMAGE_TOKEN_COUNT, MAX_VALUE_COUNT, IMAGE_SIZE, TIME_OUT
from structures.erors.SomethingWentWrong import SomeThingWentWrong
from structures.erors.TooManyRequests import TooManyRequests


async def image_complete(prompt: str) -> [str, int]:
    try:
        complete = openai_async.generate_img(
            "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",
            timeout=TIME_OUT,
            payload={
                "prompt": prompt,
                "n": MAX_VALUE_COUNT,
                "size": IMAGE_SIZE
            }
        )
        response = complete.json()["data"][0]["url"]
        return response, IMAGE_TOKEN_COUNT

    except Exception as error:
        if complete.status_code == 429:
            raise TooManyRequests(error)
        else:
            raise SomeThingWentWrong(error)