from typing import Union

from sqlalchemy.engine.url import URL
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession
from sqlalchemy.ext.asyncio import create_async_engine as _create_async_engine
from sqlalchemy.orm import sessionmaker
from .repositories import PromoCodeRepo, UsedPromoCodeRepo, UsersRepo


def create_async_engine(url: Union[URL, str]) -> AsyncEngine:
    """Create async engine"""
    return _create_async_engine(url=url,
                                echo=False,
                                pool_pre_ping=True)


def create_session_maker(engine: AsyncEngine = None) -> sessionmaker:
    """Create session maker"""
    return sessionmaker(
        engine or create_async_engine(),
        _class=AsyncSession,
        expire_on_commit=False
    )


class Database:
    User: UsersRepo
    promo_codes: PromoCodeRepo
    Used_promo_codes: UsedPromoCodeRepo
    session: AsyncSession

    def __int__(
            self,
            session: AsyncSession,
            User: UsersRepo = None,
            promo_code: PromoCodeRepo = None,
            used_promo_code: UsedPromoCodeRepo = None,
    ):
        self.session = session
        self.users = User or UsersRepo(session=session)
        self.promo_codes = promo_code or PromoCodeRepo(session=session)
        self.used_promo_code = used_promo_code or UsedPromoCodeRepo(session=session)
