from dataclasses import dataclass
from datetime import datetime
from sqlalchemy import BigInteger, INTEGER, VARCHAR, DATE
from sqlalchemy.orm import mapped_column, Mapped

from data_base.models.base import Base
from structures.enums.roles import Role


@dataclass
class User(Base):
    __tablename__ = 'users'


# Telegram ID
tg_id: Mapped[int] = mapped_column(BigInteger,
                                     unique=True,
                                     nullable=False,
                                     primary_key=True)
# Telegram user client name
user_id: Mapped[str] = mapped_column(VARCHAR(64),
                                     unique=False,
                                     nullable=False)
# Telegram first name
first_name: Mapped[str] = mapped_column(VARCHAR(64),
                                        unique=False,
                                        nullable=False)
# Telegram second name
second_name: Mapped[str] = mapped_column(VARCHAR(64),
                                         unique=False,
                                         nullable=False)
# Telegram second name
role: Mapped[Role] = mapped_column(INTEGER,
                                   unique=False,
                                   nullable=False,
                                   default= Role.user)
# Telegram ID by whom the users was invited
referral_id: Mapped[int] = mapped_column(BigInteger,
                                         unique=False,
                                         nullable=True)


def __str__(self) -> str:
    return f"<User {self.user_id}"
