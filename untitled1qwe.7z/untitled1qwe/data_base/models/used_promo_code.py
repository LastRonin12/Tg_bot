from dataclasses import dataclass
from datetime import datetime
from sqlalchemy import BigInteger, INTEGER, VARCHAR, DATE
from sqlalchemy.orm import mapped_column, Mapped

from data_base.models.base import Base


@dataclass
class Used_promo_codes(Base):
    __tablename__ = 'used_promo_codes'


#  ID
id: Mapped[int] = mapped_column(INTEGER,
                                unique=True,
                                nullable=False,
                                autoincrement=True,
                                primary_key=True)

# Telegram ID
used_id: Mapped[int] = mapped_column(BigInteger,
                                     unique=False,
                                     nullable=False)

# used_promo_code
used_promo_code: Mapped[str] = mapped_column(VARCHAR(64),
                                             unique=False,
                                             nullable=False)
