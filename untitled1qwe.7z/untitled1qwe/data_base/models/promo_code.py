from dataclasses import dataclass
from datetime import datetime
from sqlalchemy import BigInteger, INTEGER, VARCHAR, DATE
from sqlalchemy.orm import mapped_column, Mapped

from data_base.models.base import Base


@dataclass
class promo_codes(Base):
    __tablename__ = 'promo_codes'


# promo_code
promo_code: Mapped[str] = mapped_column(VARCHAR(64),
                                        unique=False,
                                        nullable=False,
                                        primary_key=True)
# tokens
tokens: Mapped[int] = mapped_column(INTEGER,
                                    unique=False,
                                    nullable=False)
# end_date_time
end_date_time: Mapped[datetime] = mapped_column(DATE,
                                                unique=False,
                                                nullable=False)
