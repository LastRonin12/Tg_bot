from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import DATE

from data_base.models.used_promo_code import used_promo_code

from .abstract import Repository


class UsedPromoCodeRepo(Repository[used_promo_code]):
    def __init__(self, session: AsyncSession):
        super().__init__(type_model=used_promo_code, session=session)

    async def new(
            self,
            user_id: int,
            promo_code: str) -> used_promo_code:

        """        :param user_id:
        :param promo_code: Promo code
                    :param end_time: End time promo code
         """

        new_promo_code = await self.session.merge(
            promo_code(
                promo_code=promo_code,
                user_id=user_id
            )
        )
        return new_promo_code
