from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import DATE

from data_base.models.promo_code import promo_codes

from .abstract import Repository


class PromoCodeRepo(Repository[promo_codes]):
    def __init__(self, session: AsyncSession):
        super().__init__(type_model=promo_codes, session=session)

    async def new(
        self,
        promo_code: str,
        end_time: DATE
    ) -> promo_codes:
        """
        :param promo_code: Promo code
        :param end_time: End time promo code
        """
        new_promo_code = await self.session.merge(
            promo_codes(
                promo_code=promo_code,
                end_time=end_time
            )
        )
        return new_promo_code