from sqlalchemy.ext.asyncio import AsyncSession

from data_base.models.Users import User
from structures.enums.roles import Role
from .abstract import Repository


class UsersRepo(Repository[User]):
    def __init__(self, session: AsyncSession):
        super().__init__(type_model=User, session=session)

    async def new(
            self,
            user_id: int,
            tg_id : int,
            first_name: str,
            second_name: str,
            role: Role,
            referral_id: int):

        new_user_id = await self.session.merge(
            user_id(
                user_id=user_id,
                tg_id=tg_id,
                first_name=first_name,
                second_name=second_name,
                role=role,
                referral_id=referral_id
            )
        )