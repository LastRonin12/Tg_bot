from typing import Any, Awaitable, Callable, Dict, Union
from aiogram import BaseMiddleware
from  aiogram.types import CallbackQuery, Message


class DatabaseMiddleware(BaseMiddleware):
    async def __call__(self,
                       handler: Callable[[Message, Dict[str, Any]], Awaitable[Any]],
                       event: Union[Message, CallbackQuery],
                       data: Union[TransferData, TransferUserData]):

