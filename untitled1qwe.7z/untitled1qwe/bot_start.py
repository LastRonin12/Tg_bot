import logging

import openai

from aiogram import Bot, Dispatcher, types
from aiogram.filters import Text, Command
from aiogram.fsm import storage
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from random import randint
import asyncio
from aiogram import Bot, Dispatcher

from data_base.data_base import create_session_maker
from parameters.chat_gpt_parameters import OPEN_AI_API_KEY
from parameters.telegram_parameters import TELEGRAM_BOT_TOKEN
from structures.data_structers import TransferData

max_token_count=200

bot = Bot(token=TELEGRAM_BOT_TOKEN)
dp = Dispatcher()

messages = [
    {
        "role" : "user",
        "content":"привет"
    }
]

def update(messages, role, content):
    messages.append({"role" : role,
                     "content":content})

def reset_messeges():
    messages.clear()
    messages.append({"role" : "user",
                       "content":"привет"})

async def main():
    await dp.start_polling(bot)

@dp.message(Command("help"))
async def help(message: types.Message):
    await message.answer("/reset - обнуляет сообщения")

@dp.message(Command("start"))
async def start(message: types.Message):
    button = InlineKeyboardButton(text="Заинтересован пупсик?", callback_data="random")
    keyboard = InlineKeyboardMarkup(inline_keyboard=[[button]])
    await message.answer("Здравствуйте", reply_markup=keyboard)

@dp.message()
async def send(message: types.Message):
    update(messages, 'user', message.text)
    response = openai.ChatCompletion.create(
        OPEN_AI_API_KEY,
        model="gpt-3.5-turbo",
        messages=messages,
        max_tokens=max_token_count,
        )
    if response['usage']['total_tokens'] >= max_token_count:
        reset_messeges()
    await message.answer(response['choices'][0]['message']['content'], parse_mode="markdown")

@dp.message(Command("reset"))
async def reset(message: types.Message):
    await message.answer("ВЫ ТОЧНО ХОТИТЕ ОЧИСТИТЬ ЧАТ? ИЛИ ВЫ ПРОСТО КАБАЧОК?")
    reset_messeges()

@dp.callback_query(Text("random"))
async def cmd_random(message: types.Message):
    await bot.send_message(chat_id=message.from_user.id, text=str(randint(0, 10)))


@dp.message()
async def echo(message: types.Message):
    await message.answer(message.text)


if __name__ == "__main__":
    try:
        asyncio.run(start_bot())
    except(KeyboardInterrupt, SystemError):
        logger.error("Bot stopped!")

logger = logging.getLogger

async def start_bot():
    logging.basicConfig(
        level=logging.INFO,
        format= u'%(filename)s:%(lineno)d #%(levelname)-8s [%(asctime)s] - %(name)s - %(message)s',
        filename='../bot history')
    logger.info('Starting bot')

    bot = Bot(token=conf.bot.token)

    transfer_data: TransferData = TransferData(pool=create_session_maker())

    dp = get_dispatcher(storage=storage)

    await set_bot_commands(bot)

    try:
        await dp.start_polling(allowed_updates=dp.resolve_used_update_types(),
        **transfer_data
            )
    finally:
        await bot.session.close()